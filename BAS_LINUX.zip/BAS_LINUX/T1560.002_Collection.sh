#!/bin/bash

# Ensure the Linux_output/Collection directory exists
ensure_output_directory() {
    local output_folder="./Linux_output/Collection"
    mkdir -p "$output_folder"
}

# Function to check for Python and install it if not present
check_python() {
    if ! which python && ! which python3; then
        echo "Python is not installed. Please install Python to run this test." | tee -a ./Linux_output/Collection/T1560.002_Collection.txt
        exit 1
    fi
}

# Function to execute SISA Test #1 - GZip Compression
execute_sisa_test1() {
    echo "Executing SISA Test #1 - Compressing data using GZip in Python" | tee -a ./Linux_output/Collection/T1560.002_Collection.txt
    which_python=$(which python || which python3)

    cat <<EOF > /tmp/sisa_test1.py
import gzip
input_file = open('/etc/passwd', 'rb')
content = input_file.read()
input_file.close()
output_file = gzip.GzipFile('/tmp/passwd.gz', 'wb', compresslevel=6)
output_file.write(content)
output_file.close()
EOF

    $which_python /tmp/sisa_test1.py 2>&1 | tee -a ./Linux_output/Collection/T1560.002_Collection.txt
    echo "SISA Test #1 complete: /etc/passwd has been compressed to /tmp/passwd.gz using GZip." | tee -a ./Linux_output/Collection/T1560.002_Collection.txt
    echo "Cleaning up for SISA Test #1" | tee -a ./Linux_output/Collection/T1560.002_Collection.txt
    rm /tmp/passwd.gz /tmp/sisa_test1.py 2>&1 | tee -a ./Linux_output/Collection/T1560.002_Collection.txt
}

# Function to execute SISA Test #2 - BZ2 Compression
execute_sisa_test2() {
    echo "Executing SISA Test #2 - Compressing data using BZ2 in Python" | tee -a ./Linux_output/Collection/T1560.002_Collection.txt
    which_python=$(which python || which python3)

    cat <<EOF > /tmp/sisa_test2.py
import bz2
input_file = open('/etc/passwd', 'rb')
content = input_file.read()
input_file.close()
bz2content = bz2.compress(content, compresslevel=9)
output_file = open('/tmp/passwd.bz2', 'wb')
output_file.write(bz2content)
output_file.close()
EOF

    $which_python /tmp/sisa_test2.py 2>&1 | tee -a ./Linux_output/Collection/T1560.002_Collection.txt
    echo "SISA Test #2 complete: /etc/passwd has been compressed to /tmp/passwd.bz2 using BZ2." | tee -a ./Linux_output/Collection/T1560.002_Collection.txt
    echo "Cleaning up for SISA Test #2" | tee -a ./Linux_output/Collection/T1560.002_Collection.txt
    rm /tmp/passwd.bz2 /tmp/sisa_test2.py 2>&1 | tee -a ./Linux_output/Collection/T1560.002_Collection.txt
}

# Function to execute SISA Test #3 - Zipfile Compression
execute_sisa_test3() {
    echo "Executing SISA Test #3 - Compressing data using Zipfile in Python" | tee -a ./Linux_output/Collection/T1560.002_Collection.txt
    which_python=$(which python || which python3)

    cat <<EOF > /tmp/sisa_test3.py
from zipfile import ZipFile
zipf = ZipFile('/tmp/passwd.zip', 'w')
try:
    zipf.write('/etc/passwd')
finally:
    zipf.close()
EOF

    $which_python /tmp/sisa_test3.py 2>&1 | tee -a ./Linux_output/Collection/T1560.002_Collection.txt
    echo "SISA Test #3 complete: /etc/passwd has been compressed to /tmp/passwd.zip using Zipfile." | tee -a ./Linux_output/Collection/T1560.002_Collection.txt
    echo "Cleaning up for SISA Test #3" | tee -a ./Linux_output/Collection/T1560.002_Collection.txt
    rm /tmp/passwd.zip /tmp/sisa_test3.py 2>&1 | tee -a ./Linux_output/Collection/T1560.002_Collection.txt
}

# Function to execute SISA Test #4 - Tarfile Compression
execute_sisa_test4() {
    echo "Executing SISA Test #4 - Compressing data using Tarfile in Python" | tee -a ./Linux_output/Collection/T1560.002_Collection.txt
    which_python=$(which python || which python3)

    cat <<EOF > /tmp/sisa_test4.py
import tarfile
tar = tarfile.open('/tmp/passwd.tar.gz', 'w:gz')
try:
    tar.add('/etc/passwd')
finally:
    tar.close()
EOF

    $which_python /tmp/sisa_test4.py 2>&1 | tee -a ./Linux_output/Collection/T1560.002_Collection.txt
    echo "SISA Test #4 complete: /etc/passwd has been compressed to /tmp/passwd.tar.gz using Tarfile." | tee -a ./Linux_output/Collection/T1560.002_Collection.txt
    echo "Cleaning up for SISA Test #4" | tee -a ./Linux_output/Collection/T1560.002_Collection.txt
    rm /tmp/passwd.tar.gz /tmp/sisa_test4.py 2>&1 | tee -a ./Linux_output/Collection/T1560.002_Collection.txt
}

# Main execution
ensure_output_directory
check_python

execute_sisa_test1
execute_sisa_test2
execute_sisa_test3
execute_sisa_test4

echo "All tests executed and logged to ./Linux_output/Collection/T1560.002_Collection.txt"
