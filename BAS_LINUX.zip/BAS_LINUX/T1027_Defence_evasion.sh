#!/bin/bash

# Atomic Test: T1027 - Decode base64 Data into Script

# Define the SISA command to encode (change as needed)
SISA_command="echo Hello from the SISA Team && uname -v"

# Define output file path
OUTPUT_FILE="./Linux_output/Defence_Evasion/T1027_output.txt"

# Encode the SISA command into base64 and store it in /tmp/encoded.dat
if [ "$(uname)" = 'FreeBSD' ]; then
    cmd="b64encode -r -"
else
    cmd="base64"
fi

echo "${SISA_command}" | $cmd > /tmp/encoded.dat

# Check if /tmp/encoded.dat exists, exit if it does
if [ ! -e "/tmp/encoded.dat" ]; then
    echo "Failed to create /tmp/encoded.dat"
    exit 1
fi

# Decode /tmp/encoded.dat into /tmp/art.sh
if [ "$(uname)" = 'FreeBSD' ]; then
    cmd="b64decode -r"
else
    cmd="base64 -d"
fi

$cmd /tmp/encoded.dat > /tmp/art.sh

# Make /tmp/art.sh executable
chmod +x /tmp/art.sh

# Execute /tmp/art.sh and capture the output
output=$(/tmp/art.sh)

# Clean up: remove /tmp/encoded.dat and /tmp/art.sh
rm /tmp/encoded.dat /tmp/art.sh

# Store output with additional information
{
    echo "Atomic Test T1027 - Decode base64 Data into Script completed."
    echo "${output}"
    echo
    echo "1. The script decodes base64-encoded data from /tmp/encoded.dat into a SISA script /tmp/art.sh."
    echo "2. It executes /tmp/art.sh, which prints:"
    echo "\"${output}\"."
    echo "3. Finally, it cleans up by removing /tmp/encoded.dat and /tmp/art.sh."
} > "${OUTPUT_FILE}"

echo "Output stored in ${OUTPUT_FILE}"
