#!/bin/bash

# Variables
module_name="T1547006"
module_path="/tmp/T1547.006/$module_name.ko"
temp_folder="/tmp/T1547.006"
output_folder="./Linux_output/Privilege_Escalation"
output_file="$output_folder/T1547.006_Privilege_Escalation.txt"

# Kernel module source code
kernel_module_code='
#include <linux/module.h>
#include <linux/kernel.h>

int init_module(void) {
    printk(KERN_INFO "Hello, world\n");
    return 0;
}

void cleanup_module(void) {
    printk(KERN_INFO "Goodbye, world\n");
}

MODULE_LICENSE("GPL");
MODULE_DESCRIPTION("Simple Kernel Module");
MODULE_AUTHOR("OpenAI");
'

# Makefile for kernel module
makefile_code='
obj-m += T1547006.o

all:
\tmake -C /lib/modules/$(shell uname -r)/build M=$(PWD) modules

clean:
\tmake -C /lib/modules/$(shell uname -r)/build M=$(PWD) clean
'

# Function to install kernel headers if not present
function install_kernel_headers {
    local kernel_version=$(uname -r)
    if ! dpkg -l | grep -q linux-headers-$kernel_version; then
        echo "Kernel headers not found. Installing..." | tee -a "$output_file"
        sudo apt update
        if ! sudo apt install -y linux-headers-$kernel_version; then
            echo "Failed to install specific kernel headers. Trying generic headers..." | tee -a "$output_file"
            if ! sudo apt install -y linux-headers-generic; then
                echo "Failed to install kernel headers. Exiting." | tee -a "$output_file"
                exit 1
            fi
        fi
    else
        echo "Kernel headers already installed." | tee -a "$output_file"
    fi
}

# Function to load kernel module
function load_kernel_module {
    if [ ! -f "$module_path" ]; then
        echo "Kernel module not found at $module_path, compiling..." | tee -a "$output_file"
        compile_kernel_module
    else
        echo "Kernel module found at $module_path, loading..." | tee -a "$output_file"
    fi

    sudo insmod "$module_path"

    if lsmod | grep "$module_name" &> /dev/null; then
        echo "Kernel module $module_name loaded successfully." | tee -a "$output_file"
    else
        echo "Failed to load kernel module $module_name." | tee -a "$output_file"
    fi
}

# Function to compile kernel module
function compile_kernel_module {
    if [ ! -d "$temp_folder" ]; then
        mkdir -p "$temp_folder"
    fi

    echo "$kernel_module_code" > "$temp_folder/$module_name.c"
    echo -e "$makefile_code" > "$temp_folder/Makefile"
    cd "$temp_folder" || exit
    make | tee -a "$output_file"

    if [ -f "$temp_folder/$module_name.ko" ]; then
        mv "$temp_folder/$module_name.ko" "$module_path"
    else
        echo "Compilation failed. Kernel module not found." | tee -a "$output_file"
        exit 1
    fi
}

# Function to clean up kernel module and temporary files
function cleanup {
    sudo rmmod "$module_name"
    if [ -f "$temp_folder/safe_to_delete" ]; then
        rm -rf "$temp_folder"
    fi
    echo "Cleanup completed." | tee -a "$output_file"
}

# Main script logic to execute chosen test
echo "=========================================================="
echo "           Executing Chosen SISA Test (T1547.006)        "
echo "==========================================================" | tee -a "$output_file"

# Ensure kernel headers are installed
install_kernel_headers

# Create the output folder if it doesn't exist
mkdir -p "$output_folder"

# Redirect all output to the output file
{
    # Load kernel module
    load_kernel_module

    echo "All chosen SISA tests executed." | tee -a "$output_file"

    # Cleanup
    cleanup
} | tee -a "$output_file"

echo "=========================================================="
echo "         Execution Completed. Output saved to $output_file  "
echo "==========================================================" | tee -a "$output_file"
