#!/bin/bash

# Define variables
cert_filename="rootCA.crt"
key_filename="rootCA.key"
output_dir="./Linux_output/Defence_Evasion"
output_file="${output_dir}/T1553.004_Defence_evasion.txt"

# Function to generate key and certificate
generate_cert() {
    openssl genrsa -out "${key_filename}" 4096
    openssl req -x509 -new -nodes -key "${key_filename}" -sha256 -days 365 -subj "/C=US/ST=Denial/L=Springfield/O=Dis/CN=www.example.com" -out "${cert_filename}"
}

# Function to install root CA on CentOS/RHEL
install_ca_centos_rhel() {
    echo "Installing root CA on CentOS/RHEL..."
    cp "${cert_filename}" /etc/pki/ca-trust/source/anchors/
    update-ca-trust
}

# Function to install root CA on FreeBSD
install_ca_freebsd() {
    echo "Installing root CA on FreeBSD..."
    cp "${cert_filename}" /usr/local/share/certs/
    certctl rehash
}

# Function to install root CA on Debian/Ubuntu
install_ca_debian_ubuntu() {
    echo "Installing root CA on Debian/Ubuntu..."
    mv "${cert_filename}" /usr/local/share/ca-certificates/
    update-ca-certificates
}

# Function to clean up
cleanup() {
    echo "Cleaning up..."
    if [[ -f "/etc/pki/ca-trust/source/anchors/${cert_filename}" ]]; then
        rm "/etc/pki/ca-trust/source/anchors/${cert_filename}"
        update-ca-trust
    fi
    if [[ -f "/usr/local/share/certs/${cert_filename}" ]]; then
        rm "/usr/local/share/certs/${cert_filename}"
        certctl rehash
    fi
    if [[ -f "/usr/local/share/ca-certificates/${cert_filename}" ]]; then
        rm "/usr/local/share/ca-certificates/${cert_filename}"
        update-ca-certificates
    fi
}

# Main script logic
if [[ "$1" == "cleanup" ]]; then
    cleanup
    exit 0
fi

# Check for prerequisites and generate certificate if necessary
if [[ ! -f "${cert_filename}" ]]; then
    echo "Generating root CA certificate and key..."
    generate_cert
fi

# Redirect all output to the output file
{
    # Print command being executed
    echo "\$ bash T1553.004_Defence_evasion.sh"
    echo ""

    # Generate certificate and install root CA
    generate_cert
    if [[ -f /etc/redhat-release ]]; then
        install_ca_centos_rhel
    elif [[ -f /usr/local/etc/pkg/repos/FreeBSD.conf ]]; then
        install_ca_freebsd
    elif [[ -f /etc/debian_version ]]; then
        install_ca_debian_ubuntu
    else
        echo "Unsupported operating system."
        exit 1
    fi

    echo "Root CA installation completed."
} > "${output_file}" 2>&1  # Redirect both stdout and stderr to the output file

echo "Output saved to: ${output_file}"
