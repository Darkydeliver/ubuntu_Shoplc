#!/bin/bash

output_folder="./Linux_output/Discovery"
output_file="$output_folder/discovery_output.txt"

# Create output folders if they don't exist
mkdir -p "$output_folder" || { echo "Failed to create directory: $output_folder"; exit 1; }

{
    # System Owner/User Discovery - T1033
    echo "System Owner/User Discovery - T1033:"
    echo "users:"
    users
    echo
    echo "w:"
    w
    echo
    echo "who:"
    who
    echo
    
    # Enumerate all accounts (Local)
    echo "Enumerate all accounts (Local):"
    cat /etc/passwd
    echo
    
    # View sudoers access
    echo "View sudoers access:"
    if [ -f /etc/sudoers ]; then sudo cat /etc/sudoers; fi
    if [ -f /usr/local/etc/sudoers ]; then sudo cat /usr/local/etc/sudoers; fi
    echo
    
    # View accounts with UID 0
    echo "View accounts with UID 0:"
    grep 'x:0:' /etc/passwd
    grep '*:0:' /etc/passwd
    echo

    # List opened files by user
    echo "List opened files by user:"
    username=$(id -u -n)
    lsof -u $username 2>/dev/null
    echo

    # Show if a user account has ever logged in remotely
    echo "Show if a user account has ever logged in remotely:"
    [ "$(uname)" = 'FreeBSD' ] && cmd="lastlogin" || cmd="lastlog"
    $cmd
    echo

    # Enumerate users and groups
    echo "Enumerate users and groups:"
    groups
    id
    echo

    # Detect Virtualization Environment (Linux)
    echo "Detect Virtualization Environment (Linux):"
    if systemd-detect-virt; then echo "Virtualization Environment detected"; fi
    if sudo dmidecode | egrep -i 'manufacturer|product|vendor' | grep -iE 'Oracle|VirtualBox|VMWare|Parallels'; then echo "Virtualization Environment detected"; fi
    echo

    # System Service Discovery - systemctl/service
    echo "System Service Discovery - systemctl/service:"
    if [ "$(uname)" = 'FreeBSD' ]; then service -e; else systemctl --type=service; fi
    echo

    # Network Share Discovery - linux
    echo "Network Share Discovery - linux:"
    sudo smbstatus --shares
    echo

    # List OS Information
    echo "List OS Information:"
    uname -a
    if [ -f /etc/lsb-release ]; then cat /etc/lsb-release; fi
    if [ -f /etc/redhat-release ]; then cat /etc/redhat-release; fi
    if [ -f /etc/issue ]; then cat /etc/issue; fi
    if [ -f /etc/os-release ]; then cat /etc/os-release; fi
    uptime
    echo

    # Linux VM Check via Hardware
    echo "Linux VM Check via Hardware:"
    if [ -f /sys/class/dmi/id/bios_version ]; then cat /sys/class/dmi/id/bios_version | grep -i amazon; fi
    if [ -f /sys/class/dmi/id/product_name ]; then cat /sys/class/dmi/id/product_name | grep -i "Droplet\|HVM\|VirtualBox\|VMware"; fi
    if [ -f /sys/class/dmi/id/chassis_vendor ]; then cat /sys/class/dmi/id/chassis_vendor | grep -i "Xen\|Bochs\|QEMU"; fi
    if [ -x "$(command -v dmidecode)" ]; then sudo dmidecode | grep -i "microsoft\|vmware\|virtualbox\|quemu\|domu"; fi
    if [ -f /proc/scsi/scsi ]; then cat /proc/scsi/scsi | grep -i "vmware\|vbox"; fi
    if [ -f /proc/ide/hd0/model ]; then cat /proc/ide/hd0/model | grep -i "vmware\|vbox\|qemu\|virtual"; fi
    if [ -x "$(command -v lspci)" ]; then sudo lspci | grep -i "vmware\|virtualbox"; fi
    if [ -x "$(command -v lscpu)" ]; then sudo lscpu | grep -i "Xen\|KVM\|Microsoft"; fi
    echo

    # Linux VM Check via Kernel Modules
    echo "Linux VM Check via Kernel Modules:"
    sudo lsmod | grep -i "vboxsf\|vboxguest"
    sudo lsmod | grep -i "vmw_baloon\|vmxnet"
    sudo lsmod | grep -i "xen-vbd\|xen-vnif"
    sudo lsmod | grep -i "virtio_pci\|virtio_net"
    sudo lsmod | grep -i "hv_vmbus\|hv_blkvsc\|hv_netvsc\|hv_utils\|hv_storvsc"
    echo

    # Hostname Discovery
    echo "Hostname Discovery:"
    hostname
    echo

    # Environment variables discovery
    echo "Environment variables discovery:"
    env
    echo

    # List Mozilla Firefox Bookmark Database Files
    echo "List Mozilla Firefox Bookmark Database Files:"
    find / -path "*.mozilla/firefox/*/places.sqlite" 2>/dev/null -exec echo {} \;
    echo

    # List Google Chrome Bookmark
    echo "List Google Chrome Bookmark:"
    find / -path "*/Google/Chrome/*/Bookmarks" 2>/dev/null -exec echo {} \;
    echo

    # System Network Configuration Discovery
    echo "System Network Configuration Discovery:"
    if [ "$(uname)" = 'FreeBSD' ]; then cmd="netstat -Sp tcp"; else cmd="netstat -ant"; fi
    if [ -x "$(command -v arp)" ]; then arp -a; else echo "arp is missing from the machine. skipping..."; fi
    if [ -x "$(command -v ifconfig)" ]; then ifconfig; else echo "ifconfig is missing from the machine. skipping..."; fi
    if [ -x "$(command -v ip)" ]; then ip addr; else echo "ip is missing from the machine. skipping..."; fi
    if [ -x "$(command -v netstat)" ]; then $cmd | awk '{print $NF}' | grep -v '[[:lower:]]' | sort | uniq -c; else echo "netstat is missing from the machine. skipping..."; fi
    echo

    # Nix File and Directory Discovery
    echo "Nix File and Directory Discovery:"
    ls -a
    if [ -d /Library/Preferences/ ]; then ls -la /Library/Preferences/; fi
    file */*
    find . -type f 2>/dev/null
    ls -R | grep ":$" | sed -e 's/:$//' -e 's/[^-][^\/]*\//--/g' -e 's/^/ /' -e 's/-/|/'
    which sh
    echo

    # System Network Connections Discovery
    echo "System Network Connections Discovery:"
    netstat
    who -a
    echo

    # Process Discovery - ps
    echo "Process Discovery - ps:"
    ps
    ps aux
    echo

    # Permission Groups Discovery (Local)
    echo "Permission Groups Discovery (Local):"
    if [ -x "$(command -v dscacheutil)" ]; then dscacheutil -q group; else echo "dscacheutil is missing from the machine. skipping..."; fi
    if [ -x "$(command -v dscl)" ]; then dscl . -list /Groups; else echo "dscl is missing from the machine. skipping..."; fi
    if [ -x "$(command -v groups)" ]; then groups; else echo "groups is missing from the machine. skipping..."; fi
    if [ -x "$(command -v id)" ]; then id; else echo "id is missing from the machine. skipping..."; fi
    if [ -x "$(command -v getent)" ]; then getent group; else echo "getent is missing from the machine. skipping..."; fi
    cat /etc/group
    echo

    # Examine password complexity policy - Ubuntu
    echo "Examine password complexity policy - Ubuntu:"
    cat /etc/pam.d/common-password
    echo

    # Discover System Language with locale
    echo "Discover System Language with locale:"
    locale
    echo

    # System Task Scheduler Discovery
    echo "System Task Scheduler Discovery:"
    if [ "$(uname)" = 'FreeBSD' ]; then crontab -l; else crontab -l; fi
    if [ -d /etc/cron.d ]; then ls -la /etc/cron.d; fi
    if [ -d /etc/cron.hourly ]; then ls -la /etc/cron.hourly; fi
    if [ -d /etc/cron.daily ]; then ls -la /etc/cron.daily; fi
    if [ -d /etc/cron.weekly ]; then ls -la /etc/cron.weekly; fi
    if [ -d /etc/cron.monthly ]; then ls -la /etc/cron.monthly; fi
    if [ -d /etc/at.d ]; then ls -la /etc/at.d; fi
    if [ -d /var/spool/cron/crontabs ]; then ls -la /var/spool/cron/crontabs; fi
    echo

    # Miscellaneous Discovery
    echo "Miscellaneous Discovery:"
    find / -name '*.dat' -print 2>/dev/null
    find / -name '*.db' -print 2>/dev/null
    find / -name '*.sqlite' -print 2>/dev/null
    echo
} > "$output_file" 2>&1

echo "Output saved to $output_file"
