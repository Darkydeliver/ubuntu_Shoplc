   
#!/bin/bash

# Function to create C files in current directory
function create_c_files {
    local src_dir="./src"
    local hello_c="$src_dir/hello.c"
    local cap_c="$src_dir/cap.c"
    
    # Ensure src directory exists
    mkdir -p "$src_dir"
    
    # Create hello.c if not exists
    if [ ! -f "$hello_c" ]; then
        cat > "$hello_c" <<EOF
#include <stdio.h>

int main() {
    printf("Hello, world!\\n");
    return 0;
}
EOF
    fi
    
    # Create cap.c if not exists
    if [ ! -f "$cap_c" ]; then
        cat > "$cap_c" <<EOF
#include <stdio.h>

int main() {
    printf("Hello from cap.c program.\\n");
    return 0;
}
EOF
    fi
}

# Function for SISA Test #1 - Make and modify binary from C source
function sisa_test_1 {
    create_c_files  # Ensure C files are created

    local src_dir="./src"
    local hello_c="$src_dir/hello.c"
    local hello_bin="/tmp/hello"

    cp "$hello_c" /tmp/hello.c
    sudo chown root /tmp/hello.c

    # Compile hello.c directly
    echo "cc     /tmp/hello.c   -o /tmp/hello"
    gcc -o "$hello_bin" /tmp/hello.c
    sudo chown root "$hello_bin"
    sudo chmod u+s "$hello_bin"
    "$hello_bin"
}

# Function for SISA Test #7 - Make and modify capabilities of a binary
function sisa_test_7 {
    create_c_files  # Ensure C files are created

    local src_dir="./src"
    local cap_c="$src_dir/cap.c"
    local cap_bin="/tmp/cap"

    cp "$cap_c" /tmp/cap.c

    # Compile cap.c directly
    echo "cc     /tmp/cap.c   -o /tmp/cap"
    gcc -o "$cap_bin" /tmp/cap.c
    sudo setcap cap_setuid=ep "$cap_bin"
    "$cap_bin"
}

# Function for SISA Test #3 - Set a SetUID flag on file
function sisa_test_3 {
    local file_to_setuid="/tmp/evilBinary"
    sudo touch "$file_to_setuid"
    sudo chown root "$file_to_setuid"
    sudo chmod u+xs "$file_to_setuid"
}

# Function for SISA Test #5 - Set a SetGID flag on file
function sisa_test_5 {
    local file_to_setgid="/tmp/evilBinary"
    sudo touch "$file_to_setgid"
    sudo chown root "$file_to_setgid"
    sudo chmod g+xs "$file_to_setgid"
}

# Function for SISA Test #8 - Provide the SetUID capability to a file
function sisa_test_8 {
    local file_to_setcap="/tmp/evilBinary"
    touch "$file_to_setcap"
    sudo setcap cap_setuid=ep "$file_to_setcap"
}

# Function for SISA Test #9 - Do reconnaissance for files that have the setuid bit set
function sisa_test_9 {
    find /usr/bin -perm -4000
}

# Function for SISA Test #10 - Do reconnaissance for files that have the setgid bit set
function sisa_test_10 {
    find /usr/bin -perm -2000
}

# Main script logic to execute chosen tests
echo "Executing chosen SISA tests..."

# Uncomment and adjust below to execute specific tests
# Each function call should be uncommented to execute the corresponding test

# sisa_test_1  # Uncomment to execute SISA Test #1
# sisa_test_3  # Uncomment to execute SISA Test #3
# sisa_test_5  # Uncomment to execute SISA Test #5
# sisa_test_7  # Uncomment to execute SISA Test #7
# sisa_test_8  # Uncomment to execute SISA Test #8
# sisa_test_9  # Uncomment to execute SISA Test #9
# sisa_test_10 # Uncomment to execute SISA Test #10

# Example: Execute all tests
sisa_test_1
sisa_test_3
sisa_test_5
sisa_test_7
sisa_test_8
sisa_test_9
sisa_test_10

echo "All chosen SISA tests executed."

# Function to check and create output folders if not present
function check_and_create_folders {
    local output_dir="./Linux_output"
    local defence_evasion_dir="$output_dir/Defence_Evasion"
    local output_file="$defence_evasion_dir/T1548.001_Defence_evasion.txt"

    # Create Linux_output folder if not exists
    if [ ! -d "$output_dir" ]; then
        mkdir -p "$output_dir"
    fi

    # Create Defence_Evasion folder if not exists
    if [ ! -d "$defence_evasion_dir" ]; then
        mkdir -p "$defence_evasion_dir"
    fi

    # Redirect all script outputs to the text file
    {
        echo "Executing chosen SISA tests..."
        # Uncomment and adjust below to execute specific tests
        # Each function call should be uncommented to execute the corresponding test

        # sisa_test_1  # Uncomment to execute SISA Test #1
        # sisa_test_3  # Uncomment to execute SISA Test #3
        # sisa_test_5  # Uncomment to execute SISA Test #5
        # sisa_test_7  # Uncomment to execute SISA Test #7
        # sisa_test_8  # Uncomment to execute SISA Test #8
        # sisa_test_9  # Uncomment to execute SISA Test #9
        # sisa_test_10 # Uncomment to execute SISA Test #10

        # Example: Execute all tests
        sisa_test_1
        sisa_test_3
        sisa_test_5
        sisa_test_7
        sisa_test_8
        sisa_test_9
        sisa_test_10

        echo "All chosen SISA tests executed."
    } > "$output_file"

    echo "Output saved to: $output_file"
}

check_and_create_folders
