import requests
import sys


def upload_file(file_path, expiration="1d"):
    url = f"https://file.io/?expires={expiration}"
    files = {'file': open(file_path, 'rb')}

    # Upload the file
    response = requests.post(url, files=files)
    response_data = response.json()

    # Check if the upload was successful
    if response_data.get("success"):
        download_link = response_data.get("link")
        print(f"File uploaded successfully. Download link: {download_link}")
        return download_link
    else:
        print(f"Error uploading file: {response_data.get('message')}")
        return None


def download_file(download_link, output_path):
    # Download the file
    response = requests.get(download_link)

    if response.status_code == 200:
        with open(output_path, 'wb') as file:
            file.write(response.content)
        print(f"File downloaded successfully to {output_path}")
    else:
        print(f"Error downloading file: {response.status_code} - {response.text}")


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python script.py <file_path>")
        sys.exit(1)

    file_path = sys.argv[1]
    output_path = "downloaded_" + file_path

    # Upload and get download link
    download_link = upload_file(file_path)

    # Download the file if the upload was successful
    #if download_link:
    #    download_file(download_link, output_path)