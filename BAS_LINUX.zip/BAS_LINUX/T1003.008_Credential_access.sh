#!/bin/bash

# Define the output directory and file
output_dir="Linux_output/Credential_access"
mkdir -p "$output_dir"
output_file="${output_dir}/T1003.008_Credential_access.txt"

# Function to run a test and log its output
run_test() {
    local test_number="$1"
    local description="$2"
    local attack_commands="$3"
    local cleanup_commands="$4"

    # Display initial messages in the terminal
    echo "Running SISA Test #$test_number - $description"
    echo "Supported Platforms: Linux"
    echo ""
    echo "Inputs:"
    echo "Name    Description    Type    Default Value"
    echo "output_file    Path where captured results will be placed    path    /tmp/T1003.008.txt"
    echo "Attack Commands: Run with bash! Elevation Required (e.g. root or admin)"
    echo "$attack_commands"
    echo "Cleanup Commands:"
    echo "$cleanup_commands"
    echo ""

    # Execute attack commands and capture all output to the log file
    echo "Executing attack commands..."
    echo "### START OF OUTPUT FOR SISA Test #$test_number - $description ###" >> "$output_file"
    eval "$attack_commands" | tee -a "$output_file"
    echo "### END OF OUTPUT FOR SISA Test #$test_number - $description ###" >> "$output_file"

    # Execute cleanup commands and capture all output to the log file
    echo "Executing cleanup commands..."
    echo "### START OF CLEANUP OUTPUT FOR SISA Test #$test_number - $description ###" >> "$output_file"
    eval "$cleanup_commands" | tee -a "$output_file"
    echo "### END OF CLEANUP OUTPUT FOR SISA Test #$test_number - $description ###" >> "$output_file"

    # Display completion message in the terminal
    echo "SISA Test #$test_number - $description completed."
    echo "---------------------------------------------"
    echo ""
}

# SISA Test #1
test_number="1"
description="Access /etc/shadow (Local)"
attack_commands="sudo cat /etc/shadow"
cleanup_commands=""  # No cleanup needed as we're appending to the file
run_test "$test_number" "$description" "$attack_commands" "$cleanup_commands"

# SISA Test #2
test_number="2"
description="Access /etc/master.passwd (Local)"
attack_commands="sudo cat /etc/master.passwd"
cleanup_commands=""
run_test "$test_number" "$description" "$attack_commands" "$cleanup_commands"

# SISA Test #3
test_number="3"
description="Access /etc/passwd (Local)"
attack_commands="cat /etc/passwd"
cleanup_commands=""
run_test "$test_number" "$description" "$attack_commands" "$cleanup_commands"

# SISA Test #4
test_number="4"
description="Access /etc/{shadow,passwd,master.passwd} with a standard bin that's not cat"
attack_commands='unamestr=$(uname); if [ "$unamestr" = "Linux" ]; then echo -e "e /etc/passwd\n,p\ne /etc/shadow\n,p\n" | ed; elif [ "$unamestr" = "FreeBSD" ]; then echo -e "e /etc/passwd\n,p\ne /etc/master.passwd\n,p\ne /etc/shadow\n,p\n" | ed; fi'
cleanup_commands=""
run_test "$test_number" "$description" "$attack_commands" "$cleanup_commands"

# SISA Test #5
test_number="5"
description="Access /etc/{shadow,passwd,master.passwd} with shell builtins"
attack_commands='testcat(){ (while read line; do echo $line; done < $1) }; [ "$(uname)" = "FreeBSD" ] && testcat /etc/master.passwd; testcat /etc/passwd; testcat /etc/shadow'
cleanup_commands=""
run_test "$test_number" "$description" "$attack_commands" "$cleanup_commands"

echo "All SISA Tests completed."
echo "Results stored in: $output_file"
